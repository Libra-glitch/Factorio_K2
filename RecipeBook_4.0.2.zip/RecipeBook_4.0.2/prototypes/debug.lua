data:extend({
  {
    type = "custom-input",
    name = "rb-debug-toggle-entity-selection",
    key_sequence = "ALT + K",
  },
  {
    type = "custom-input",
    name = "rb-debug-reload-mods",
    key_sequence = "ALT + M",
  },
})
