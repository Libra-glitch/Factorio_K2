data:extend({
  {
    type = "sprite",
    name = "rb_logo",
    filename = "__RecipeBook__/graphics/logo.png",
    size = 32,
    flags = { "gui-icon" },
  },
  {
    type = "sprite",
    name = "rb_show_hidden",
    filename = "__RecipeBook__/graphics/show-hidden.png",
    size = 32,
    flags = { "gui-icon" },
  },
  {
    type = "sprite",
    name = "rb_show_unresearched",
    filename = "__RecipeBook__/graphics/show-unresearched.png",
    size = 32,
    flags = { "gui-icon" },
  },
})
