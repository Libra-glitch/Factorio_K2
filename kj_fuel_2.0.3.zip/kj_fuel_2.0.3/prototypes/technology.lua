--Technology
data:extend({
	{
		type = "technology",
		name = "kj_gasoline",
		icon = "__kj_fuel__/graphics/tech_gasoline.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "kj_gascan"
			},
			{
				type = "unlock-recipe",
				recipe = "kj_kerosine"
			},
			{
				type = "unlock-recipe",
				recipe = "kj_gasbarrel"
			},
		},
		prerequisites = {"advanced-oil-processing"},
		unit =
		{
			count = 100,
			ingredients =
			{
				{"automation-science-pack", 1},
				{"logistic-science-pack", 1},
				{"chemical-science-pack", 1},
			},
			time = 30
		},
	},
	{
		type = "technology",
		name = "kj_energy_cell",
		icon = "__kj_fuel__/graphics/tech_energy_cell.png",
		icon_size = 132,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "kj_energy_cell_empty"
			},
			{
				type = "unlock-recipe",
				recipe = "kj_energy_cell_load"
			},
		},
		prerequisites = {"rocket-fuel", "production-science-pack"},
		unit =
		{
			count = 300,
			ingredients =
			{
				{"automation-science-pack", 1},
				{"logistic-science-pack", 1},
				{"chemical-science-pack", 1},
				{"production-science-pack", 1},
			},
			time = 30
		},
	},
})