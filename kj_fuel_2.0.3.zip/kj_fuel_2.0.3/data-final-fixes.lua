if data.raw["item-group"]["kj_vehicles"] ~= nil then
	data.raw["item-subgroup"]["kj_fuels"].group = "kj_vehicles"
	data.raw["item-subgroup"]["kj_fuels"].order = "z"
end

--[[
"kj_gas_can"
"kj_gas_barrel"
"kj_kerosine"
"kj_energy_cell"
]]

local fuels = {
	"kj_gas_can",
	"kj_gas_barrel",
	"kj_kerosine",
}

local entities = {
	["locomotive"] = "locomotive",
	["car"] = "car",
	["tank"] = "car",
	["boiler"] = "boiler",
	["burner-mining-drill"] = "mining-drill",
	["stone-furnace"] = "furnace",
	["steel-furnace"] = "furnace",
	["heating-tower"] = "reactor",
}

for _, fuel in pairs(fuels) do
	for name, type in pairs(entities) do
		local entity = data.raw[type][name]

		if entity ~= nil then
			if entity.energy_source ~= nil then
				if entity.energy_source.fuel_categories ~= nil then
					log("Adding "..fuel.." to "..name)
					table.insert(entity.energy_source.fuel_categories, fuel)
				end
			end
		end
	end
end