-- Here are the values that are shared across different files.
local faster_flame_defines = {}

-- Mod ID.
faster_flame_defines.mod_id = "faster-flame"
-- Prefix of the names.
faster_flame_defines.name_prefix = faster_flame_defines.mod_id .. "_"

-- Names.
faster_flame_defines.names = {}
-- Setting names.
faster_flame_defines.names.settings =
{
	flamethrower_turret_flame_speed		= faster_flame_defines.name_prefix .. "flamethrower-turret-flame-speed-modifier",
	handheld_flamethrower_flame_speed	= faster_flame_defines.name_prefix .. "handheld-flamethrower-flame-speed-modifier"
}

return faster_flame_defines