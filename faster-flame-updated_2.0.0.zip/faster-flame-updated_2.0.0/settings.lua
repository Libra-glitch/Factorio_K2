local faster_flame_defines = require("defines")
data:extend
{
	{
		type = "double-setting",
		name = faster_flame_defines.names.settings.flamethrower_turret_flame_speed,
		setting_type = "startup",
		default_value = 3.5,
		minimum_value = 0.01
	},
	{
		type = "double-setting",
		name = faster_flame_defines.names.settings.handheld_flamethrower_flame_speed,
		setting_type = "startup",
		default_value = 3.5,
		minimum_value = 0.01
	}
}
