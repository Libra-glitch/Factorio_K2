table.insert(data.raw["technology"]["fusion-reactor"].effects, {type = "unlock-recipe",recipe = "plasma-duct"})
data.raw["technology"]["plasma-duct"] = nil
data.raw["recipe"]["plasma-duct"].ingredients =
	{
		{type = "item", name = "tungsten-plate", amount = 5},
		{type = "item", name = "superconductor", amount = 5}
	}
data.raw.recipe["plasma-duct"].results = {{type = "item", name = "plasma-duct", amount= 10}}

data.raw.pipe["plasma-duct"].pictures.corner_down_left.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-corner-down-left.png"
data.raw.pipe["plasma-duct"].pictures.corner_down_right.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-corner-down-right.png"
data.raw.pipe["plasma-duct"].pictures.corner_up_left.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-corner-up-left.png"
data.raw.pipe["plasma-duct"].pictures.corner_up_right.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-corner-up-right.png"
data.raw.pipe["plasma-duct"].pictures.cross.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-cross.png"
data.raw.pipe["plasma-duct"].pictures.ending_down.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-ending-down.png"
data.raw.pipe["plasma-duct"].pictures.ending_left.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-ending-left.png"
data.raw.pipe["plasma-duct"].pictures.ending_right.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-ending-right.png"
data.raw.pipe["plasma-duct"].pictures.ending_up.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-ending-up.png"
data.raw.pipe["plasma-duct"].pictures.straight_horizontal.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-straight-horizontal.png"
data.raw.pipe["plasma-duct"].pictures.straight_horizontal_window.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-straight-horizontal-window.png"
data.raw.pipe["plasma-duct"].pictures.straight_vertical.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-straight-vertical.png"
data.raw.pipe["plasma-duct"].pictures.straight_vertical_single.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-straight-vertical-single.png"
data.raw.pipe["plasma-duct"].pictures.straight_vertical_window.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-straight-vertical-window.png"
data.raw.pipe["plasma-duct"].pictures.t_down.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-t-down.png"
data.raw.pipe["plasma-duct"].pictures.t_left.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-t-left.png"
data.raw.pipe["plasma-duct"].pictures.t_right.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-t-right.png"
data.raw.pipe["plasma-duct"].pictures.t_up.filename = "__plasma-duct-tweak__/graphics/entity/plasma-duct/plasma-duct-t-up.png"