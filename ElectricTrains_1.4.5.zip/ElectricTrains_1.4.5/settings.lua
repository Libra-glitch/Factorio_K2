data:extend(
{
    {
        type = "bool-setting",
        name = "deg-et-enable-space-age-changes",
        setting_type = "startup",
        default_value = true,
        order = "a"
    }
})