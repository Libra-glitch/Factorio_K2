data:extend({
    {
        type = "bool-setting",
        name = "s6x-clr-launch-on-negative",
        setting_type = "runtime-global",
        default_value = false,
        order = "aa"
    }
})