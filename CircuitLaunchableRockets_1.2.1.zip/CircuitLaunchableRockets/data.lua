data:extend({
	{
		type = "sprite",
		name = "s6x-rocket-error",
		filename = "__core__/graphics/icons/alerts/destination-full-icon.png",
		priority = "extra-high-no-scale",
		width = 64,
		height = 64,
		flags = {"icon"}
	},
	
	{
		type = "item-subgroup",
		name = "s6x-mod-virtual-signals",
		group = "signals",
		order = "zzzz"
	},
	
	{
		type = "virtual-signal",
		name = "s6x-signal-launch-rocket",
		icon = "__CircuitLaunchableRockets__/graphics/icons/signal-launch-rocket.png",
		subgroup = "s6x-mod-virtual-signals",
		order = "r"
	},
})