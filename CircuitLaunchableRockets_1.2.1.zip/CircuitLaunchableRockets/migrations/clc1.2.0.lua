storage.cargo_pod_table = nil
storage.junk_silo_table = nil
