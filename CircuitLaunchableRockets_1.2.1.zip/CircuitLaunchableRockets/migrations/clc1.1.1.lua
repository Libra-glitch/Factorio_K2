storage.active_rocket_gui_silo = nil
storage.active_rocket_gui_destination_idx = nil
