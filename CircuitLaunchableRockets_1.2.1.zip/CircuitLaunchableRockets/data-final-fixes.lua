--[[ not necessary any more!

local fake_rockets = {}
local created = {}
for rname, rocket in pairs(data.raw["rocket-silo"]) do
	local fake_rocket = util.table.deepcopy(data.raw["rocket-silo"][rname])
	local fake_rocket_entity = "s6x-fake-" .. rocket.rocket_entity
	
	fake_rocket.name = "s6x-fake-" .. rocket.name
	fake_rocket.rocket_entity = fake_rocket_entity
	fake_rocket.collision_mask = {layers={}, not_colliding_with_itself=true}
	fake_rocket.energy_source = { type = "void" }
	fake_rocket.resistances = { { type = "physical", percent = 100 }, { type = "explosion", percent = 100 } }
	fake_rocket.destructible = false
	fake_rocket.surface_conditions = nil
	fake_rocket.hidden = true
	
	if (not fake_rocket.fixed_recipe) then
		fake_rocket.fixed_recipe = "rocket-part"
	end

	table.insert(fake_rockets, fake_rocket)

	if (not created[fake_rocket_entity]) then
		local copy_from = data.raw["rocket-silo-rocket"][rocket.rocket_entity]
		local fake_rocket_launch = util.table.deepcopy(copy_from)
		fake_rocket_launch.name = fake_rocket_entity
		fake_rocket_launch.engine_starting_speed = 1 / 700
		created[fake_rocket_entity] = true
		table.insert(fake_rockets, fake_rocket_launch)
	end
end
data.extend(fake_rockets)
--]]