local launch_signal = "s6x-signal-launch-rocket"
local essential_item = {
	["space-platform-foundation"] = 5
}
local item_default_score = 2
	
function rocketsilo_built(event)
	local rocketsilo = event.entity
	
	--game.print("built event " .. rocketsilo.unit_number .. " / " .. rocketsilo.name)
	
	if (rocketsilo and rocketsilo.valid) then
		if (not storage.rocketsilo_table) then storage.rocketsilo_table = {} end
		storage.rocketsilo_table[rocketsilo.unit_number] = { entity = rocketsilo }
	end
end

function rocketsilo_mined(event)
	local rocketsilo = event.entity
	if (rocketsilo and rocketsilo.valid) then
		if (storage.rocketsilo_table) then
			local tbl = storage.rocketsilo_table[rocketsilo.unit_number]
			if (tbl.icon) then icon_cleanup(tbl) end
			storage.rocketsilo_table[rocketsilo.unit_number] = nil
		end
	end
end

function rocketsilo_mined_script(event)
	local rocketsilo = event.entity
	if (rocketsilo and rocketsilo.valid) then
		if (storage.rocketsilo_table and rocketsilo.unit_number and storage.rocketsilo_table[rocketsilo.unit_number]) then
			local tbl = storage.rocketsilo_table[rocketsilo.unit_number]
			if (tbl.icon) then icon_cleanup(tbl) end
			storage.rocketsilo_table[rocketsilo.unit_number] = nil
		end
	end
end

function rocketsilo_tick(event)
	local tick = event.tick

	--[[ superseded by cargo_pod_destination
	if (storage.vrocket_table and #storage.vrocket_table > 0 and ((tick % 5) == 2)) then
		local vr = storage.vrocket_table
		local hasrocket = false
		for n=1,#vr do
			if (vr[n]) then
				local tbl = vr[n]
				local vrocket_silo = vr[n].silo
				hasrocket = true
				if (vrocket_silo.rocket_silo_status == defines.rocket_silo_status.rocket_ready) then
					if (vrocket_silo.launch_rocket()) then
						vr[n] = false
						if (not storage.junk_silo_table) then storage.junk_silo_table = {} end
						storage.junk_silo_table[vrocket_silo.unit_number] = { val = 60, entity = vrocket_silo }
					end
				end
			end
		end
		if (not hasrocket) then storage.vrocket_table = nil end
	end
	--]]
	
	--[[ superseded by on_cargo_pod_finished_ascending
	if (storage.cargo_pod_table and #storage.cargo_pod_table > 0 and ((tick % 5) == 1)) then
		local cp = storage.cargo_pod_table
		local haspod = false
		
		for n=1,#cp do
			if (cp[n]) then
				local tbl = cp[n]
				if (tbl.entity and tbl.entity.valid) then
					haspod = true
					
					local lasttick = tbl.lasttick or -1
					local thistick = tbl.entity.procession_tick	
				
					if (thistick < lasttick) then
						tbl.entity.destroy()
						cp[n] = false
					else
						tbl.lasttick = thistick
					end
					
				else
					cp[n] = false
				end
			end
		end
		if (not haspod) then storage.cargo_pod_table = nil end
	end
	--]]
		
	--[[ superseded by cargo_pod_destination
	if (storage.junk_silo_table and ((tick % 30) == 0)) then
		local updated = false
		local del = nil
		for id, tbl in pairs(storage.junk_silo_table) do
			if (tbl) then
				if (tbl.val > 0) then
					tbl.val = tbl.val - 1
					updated = true
				elseif (tbl.entity) then
					if (tbl.entity.valid) then tbl.entity.destroy() end
					tbl.entity = nil
					del = id
				else
					del = id
				end
			end
		end
		if (not updated) then storage.junk_silo_table = nil
		elseif (del) then storage.junk_silo_table[del] = false end
	end
	--]]
	
	if (storage.rocketsilo_table) then
		local offset = 30
		local tick_mod = tick % offset
		for id, tbl in pairs(storage.rocketsilo_table) do
			if (id % offset == tick_mod) then
				if (not tbl.entity.valid) then
					storage.rocketsilo_table[id] = nil
					return
				end
				
				if (tbl.signal_timeout) then
					tbl.signal_timeout = tbl.signal_timeout - 1
					if (tbl.signal_timeout == 0) then tbl.signal_timeout = nil end
				else
					local rocketsilo = tbl.entity
					local control_behavior = rocketsilo.get_control_behavior()
					
					-- Added (rocketsilo.rocket_silo_status == defines.rocket_silo_status.rocket_ready) to avoid wasting UPS reading signals if we aren't even ready to launch
					if (control_behavior and control_behavior.valid and (rocketsilo.rocket_silo_status == defines.rocket_silo_status.rocket_ready)) then
						local rocket_signals = rocketsilo.get_signals(defines.wire_connector_id.circuit_red, defines.wire_connector_id.circuit_green)
						if (rocket_signals) then
							for s=1,#rocket_signals do
								local cs = rocket_signals[s].signal
								local valid_signal = false
								
								if (tbl.signal) then
									local signame = tbl.signal.name
									if (cs.type == tbl.signal.type and cs.name == signame) then
										valid_signal = true
									elseif (signame == "signal-everything" or signame == "signal-anything" or signame == "signal-each") then
										valid_signal = true
									end
								else
									if (cs.type == "virtual" and cs.name == launch_signal) then valid_signal = true end
								end
								
								if (valid_signal) then
									local signal_count = rocket_signals[s].count
									-- Still needed because we might handle multiple signals and could launch on any of them
									if (rocketsilo.rocket_silo_status == defines.rocket_silo_status.rocket_ready) then
										local launch_rocket = true
										
										local plats_here = {}
										local plats = rocketsilo.force.platforms
										if (plats and #plats >= 1) then
											for _, plat in pairs(plats) do
												if (plat.valid and plat.space_location) then
													if (plat.space_location.name == rocketsilo.surface.name) then
														if (plat.state == defines.space_platform_state.no_schedule or
															plat.state == defines.space_platform_state.no_path or
															plat.state == defines.space_platform_state.waiting_at_station or
															plat.state == defines.space_platform_state.paused)
														then
															table.insert(plats_here, plat)
														end
													end
												end
											end
										end
										
										local inv = rocketsilo.get_inventory(defines.inventory.rocket_silo_rocket)
										if (inv.is_empty()) then launch_rocket = false end
										
										if (launch_rocket and signal_count < 0) then
											if (not settings.global["s6x-clr-launch-on-negative"].value) then
												launch_rocket = false
											end
										end
										
										local destination 
										if (launch_rocket) then
											if (tbl.platform_dest) then
												if (tbl.platform_dest >= 0) then
													for pn=1,#plats_here do
														if (plats_here[pn].index == tbl.platform_dest) then
															destination = plats_here[pn]
															break
														end
													end
												end
											elseif (#plats_here >= 1) then
												destination = get_rocket_destination(false, tbl.entity.surface, tbl, signal_count, plats_here)
											end
										end
										
										tbl.signal_timeout = 2
										if (launch_rocket and destination) then
											if (rocketsilo.launch_rocket()) then
												if (tbl.icon) then icon_cleanup(tbl) end
												tbl.scripted_launch = true
												tbl.destination = destination
												tbl.signal_timeout = 10
											end
										else
											if (not tbl.icon or not tbl.icon.valid) then
												tbl.icon = rendering.draw_sprite({
													sprite = "s6x-rocket-error",
													render_layer = "entity-info-icon-above",
													target = { entity = tbl.entity },
													surface = tbl.entity.surface,
													x_scale = 0.5,
													y_scale = 0.5,
													only_in_alt_mode = true
												})
											end
										end
										
									end
								end
							end
						end
					end
					
					if (not tbl.signal_timeout and tbl.icon) then icon_cleanup(tbl) end
					
				end
				
			end
		end
	end
end

function get_rocket_destination(logistics_plat, src, tbl, signal_count, plats_here)

	if (not logistics_plat) then
		if (signal_count > 1) then
			for i=1,#plats_here do
				local plat = plats_here[i]
				local platnumber = string.match(plat.name, "^%d+")
				if (platnumber) then
					local convnumber = tonumber(platnumber)
					if (convnumber == signal_count) then
						return plats_here[i]
					end
				end
			end
			return false
		end
		
		if (#plats_here == 1) then return plats_here[1] end
	end

	local requests = {}
	for i=1,#plats_here do
		requests[i] = { }	
		local plat = plats_here[i]
		local logi = plat.hub.get_logistic_point()
		
		local inv = plat.hub.get_inventory(defines.inventory.hub_main)
		local platinv = {}
		local inv_c = inv.get_contents()
		for n=1,#inv_c do
			local item = inv_c[n]
			local q = (item.quality.level or 0) + 1
			if (not platinv[item.name]) then platinv[item.name] = {} end
			platinv[item.name][q] = item.count
		end
		
		for n=1,#logi do
			local lp = logi[n]
			for s=1,lp.sections_count do
				local sec = lp.sections[s]
				for f=1,sec.filters_count do
					local fil = sec.filters[f]
					if (fil.value) then
						local key = fil.value.name
						if (fil.import_from.name == src.name) then
							local qmin = 1
							local qmax = 6 -- may not work with modded quality
							local qignore = nil
							
							if (fil.value.quality) then
								local qual = fil.value.quality
								local lev = prototypes.quality[qual].level + 1
								local comp = fil.value.comparator or "?"
								if (comp == "=") then
									qmin = lev
									qmax = lev
								elseif (comp == ">") then
									qmin = lev + 1
								elseif (comp == "≥") then
									qmin = lev
								elseif (comp == "<") then
									qmax = lev - 1
								elseif (comp == "≤") then
									qmax = lev
								elseif (comp == "≠") then
									qignore = lev
								end
							end
							
							for qlev=qmin,qmax do
								if (not qignore or qlev ~= qignore) then
									if (not requests[i][qlev]) then requests[i][qlev] = { } end
									if (not requests[i][qlev][key]) then requests[i][qlev][key] = { minreq = 0, maxreq = 0, absminreq = 0, alreadygot = 0 } end
									local rq = requests[i][qlev][key]
									rq.minreq = rq.minreq + (fil.min or 0)
									rq.maxreq = rq.maxreq + (fil.max or 0)
									rq.absminreq = rq.absminreq + (fil.minimum_delivery_count or 0)
									
									if (platinv[key]) then
										for qn=qmin,qmax do
											if (not qignore or qn ~= qignore) then
												rq.alreadygot = rq.alreadygot + (platinv[key][qn] or 0)
											end
										end
									end
									
								end
							end
							
						end
					end
				end
			end
		end
	end
	
	local inv = tbl.entity.get_inventory(defines.inventory.rocket_silo_rocket)
	local inv_c = inv.get_contents()
	local platscore = {}
	for i=1,#plats_here do
		local reqs = requests[i]
		local score = 0
		for n=1,#inv_c do
			local item = inv_c[n]
			local q = (item.quality.level or 0) + 1
			if (reqs[q] and reqs[q][item.name]) then
				local rq = reqs[q][item.name]
				if (item.count >= rq.absminreq) then
					if (rq.maxreq > rq.alreadygot) then
						local item_val = math.min(item.count, rq.maxreq - rq.alreadygot)
						local mult = essential_item[item.name] or item_default_score
						score = score + (mult * item_val)
					end
				end
			end
		end
		platscore[i] = score
	end
	local bestscore, bestplat
	for i=1,#plats_here do
		if (not bestscore or platscore[i] > bestscore) then
			bestplat = i
			bestscore = platscore[i]
		end
	end
	if (bestplat) then
		--game.print("Sending rocket to " .. plats_here[bestplat].name)
		return plats_here[bestplat]
	end

	if (logistics_plat) then return false end
	return plats_here[1]
end

--[[ superseded by cargo_pod_destination
function setup_virtual_rocket_at_destination(basename, tbl, key, targ)
	local vrocket = targ.create_entity({
		name = "s6x-fake-" .. basename,
		position = {-5000, -5000},
		force = tbl.entity.force,
		create_build_effect_smoke = false,
	})
	vrocket.rocket_parts = 100
	if (not storage.vrocket_table) then storage.vrocket_table = {} end
	table.insert(storage.vrocket_table, { silo = vrocket }) -- countdown = 72
	
	return vrocket
end
--]]

function init_all_rocketsilos()
	for surf in pairs(game.surfaces) do
		local surface = game.get_surface(surf)
		local rocketsilolist = surface.find_entities_filtered({type = "rocket-silo"})
		for i=1,#rocketsilolist do
			local silo = rocketsilolist[i]
			if (string.sub(silo.name, 1, 9) ~= "s6x-fake-") then
				if (not storage.rocketsilo_table) then storage.rocketsilo_table = {} end
				storage.rocketsilo_table[silo.unit_number] = { entity = silo }
			end
		end
	end
end

--[[ superseded by cargo_pod_destination
function rocket_launch_ordered(event)
	local rocket = event.rocket
	local silo = event.rocket_silo
	if (rocket and rocket.valid and silo and silo.valid) then
		local tbl = storage.rocketsilo_table[silo.unit_number]
				
		if (tbl and rocket.cargo_pod and tbl.scripted_launch and not event.player_index) then
			local vrocket_silo = setup_virtual_rocket_at_destination(silo.prototype.name, tbl, id, tbl.destination.surface)
			local pod = rocket.cargo_pod
			
			local podinv = pod.get_inventory(defines.inventory.cargo_unit)
			local destinv = vrocket_silo.get_inventory(defines.inventory.rocket_silo_rocket)
			if (podinv and destinv) then 
				--local podinv_c = podinv.get_contents()
				for i=1,#podinv do
					if (podinv[i]) then
						destinv.insert(podinv[i])
					end
				end
			end	
		end
	end
end
--]]

function rocket_got_launched(event)
	local rocket = event.rocket
	local silo = event.rocket_silo

	if (rocket and rocket.valid and silo and silo.valid) then
		local tbl = storage.rocketsilo_table[silo.unit_number]
		if (tbl and tbl.scripted_launch) then
			tbl.scripted_launch = nil
			if (rocket.attached_cargo_pod and not event.player_index) then
				local pod = rocket.attached_cargo_pod	
				
				-- This one line replaces about half of the mod's old code!
				pod.cargo_pod_destination = {type = defines.cargo_destination.station, station = tbl.destination.hub } 

				--[[
				if (not storage.cargo_pod_table) then storage.cargo_pod_table = {} end
				table.insert(storage.cargo_pod_table, { entity = pod })
				--game.print("Rocket event at " .. event.tick)
				--]]
			end
		end
	end
end

--[[ superseded by cargo_pod_destination
function cargo_pod_launched(event)
	local pod = event.cargo_pod
	if (pod.valid and storage.cargo_pod_table) then
		local cpt = storage.cargo_pod_table
		local cptn = #cpt
		local cpt_left = 0
		for n=1,cptn do
			local del = false
			if (cpt[n]) then
				cpt_left = cpt_left + 1
				if (not cpt[n].entity.valid) then
					del = true
				elseif (cpt[n].entity == pod) then 
					--game.print("Destroying marked pod on event at " .. event.tick)
					pod.destroy()
					del = true
				end
				
				if (del) then
					cpt[n] = false
					cpt_left = cpt_left - 1
				end
			end
		end
		
		if (cpt_left == 0) then
			storage.cargo_pod_table = nil
		elseif (cptn > 100 and cpt_left < 50) then
			local ncpt = {}
			for i=1,#cptn do
				if (cpt[i]) then table.insert(ncpt, cpt[i]) end
			end
			storage.cargo_pod_table = ncpt
		end
	end
end
--]]

function icon_cleanup(tbl)
	if (tbl.icon.valid) then
		tbl.icon.destroy()
	end
	tbl.icon = nil
end

function handle_configuration_changed(event)
	if (storage.rocketsilo_table) then
		for id, tbl in pairs(storage.rocketsilo_table) do
			if (tbl.icon) then icon_cleanup(tbl) end
		end
	end
end

function rocket_gui(event)
	if (event.gui_type == defines.gui_type.entity and event.entity and event.entity.valid and event.entity.type == "rocket-silo") then
		local silo = event.entity
		local network = silo.get_circuit_network(defines.wire_connector_id.circuit_red)
		if (not network) then network = silo.get_circuit_network(defines.wire_connector_id.circuit_green) end
		if (network) then
			local tbl = storage.rocketsilo_table[silo.unit_number]
			local player = game.get_player(event.player_index)
			local gui = player.gui.relative.clc_config		
			local sigtbl = tbl.signal or { type = "virtual", name = launch_signal }
			local dest_idx = 1
			
			local destinations = {{ "clc-gui.automatic" }}
			local plats = silo.force.platforms
			local destination_idx = { -1 }
			
			if (plats and #plats >= 1) then
				for _, plat in pairs(plats) do
					if (plat.valid) then
						local plat_location = "solar-system-edge"
						if (plat.space_location) then
							plat_location = plat.space_location.name
						elseif (plat.schedule) then
							plat_location = plat.schedule.records[plat.schedule.current].station
						end
						
						local platicon = "[space-location=" .. plat_location .. "]"
						table.insert(destinations, {"", platicon, " ", plat.name})
						table.insert(destination_idx, plat.index)
					end
				end
			end

			if (tbl.platform_dest) then
				local found = false
				for i=1,#destination_idx do
					if (tbl.platform_dest == destination_idx[i]) then
						dest_idx = i
						found = true
						break
					end
				end
				if (not found) then
					table.insert(destinations,{ "clc-gui.invalid" })
					table.insert(destination_idx, -2)
					tbl.platform_dest = -2
					dest_idx = #destinations
				end
			end
			-- never deleted... does it matter?
			if (not tbl.destination_idx) then tbl.destination_idx  = {} end
			tbl.destination_idx[event.player_index] = destination_idx
			
			if (not gui) then
				gui = player.gui.relative.add({
					type = "frame",
					name = "clc_config",
					caption = { "clc-gui.title" },
					direction = "vertical",
					index = 0,
					anchor = {
						gui = defines.relative_gui_type.rocket_silo_gui,
						position = defines.relative_gui_position.right
					}
				})
				local gui_inner = gui.add({
					type = "frame",
					name = "clc_config_controls",
					style = "inside_shallow_frame_with_padding",
					direction = "vertical",
				})
				local gui_flow = gui_inner.add({
					type = "flow",
					name = "clc_config_flow",
					style = "player_input_horizontal_flow"
				})
				gui_flow.add({
					type = "label",
					name = "clc_launch_label",
					caption = { "clc-gui.signal" },
				})
				gui_flow.add({
					type = "choose-elem-button",
					name = "clc_launch_signal",
					elem_type = "signal",
					signal = sigtbl
				})
				gui_inner.add({
					type = "label",
					name = "clc_destination_label",
					style = "semibold_label",					
					caption = { "clc-gui.destination" },
				})			
				gui_inner.add({
					type = "drop-down",
					name = "clc_destination_select",
					selected_index = dest_idx,
					items = destinations
				})
			end
		end
	end
end

function rocket_gui_close(event)
	if (event.gui_type == defines.gui_type.entity and event.entity and event.entity.valid and event.entity.type == "rocket-silo") then
		local player = game.get_player(event.player_index)
		local gui = player.gui.relative.clc_config
		if (gui) then gui.destroy() end
	end
end

function rocket_gui_elem(event)
	if (event.element.name == "clc_launch_signal" or event.element.name == "clc_destination_select") then
		local player = game.get_player(event.player_index)
		local un = player.opened.unit_number
		local tbl = storage.rocketsilo_table[un]
		
		if (event.element.name == "clc_launch_signal") then
			tbl.signal = event.element.elem_value
		elseif (event.element.name == "clc_destination_select") then
			tbl.platform_dest = tbl.destination_idx[event.player_index][event.element.selected_index]
		end
	end
end

function rocket_settings_pasted(event)
	local src = event.source
	local dest = event.destination
	if (src.valid and dest.valid and storage.rocketsilo_table) then
		if (storage.rocketsilo_table[src.unit_number] and storage.rocketsilo_table[dest.unit_number]) then
			local stbl = storage.rocketsilo_table[src.unit_number]
			local dtbl = storage.rocketsilo_table[dest.unit_number]
			dtbl.signal = stbl.signal
			dtbl.platform_dest = stbl.platform_dest
		end
	end
end

script.on_event(defines.events.on_built_entity, rocketsilo_built, {{filter = "type", type = "rocket-silo"}})
script.on_event(defines.events.on_robot_built_entity, rocketsilo_built, {{filter = "type", type = "rocket-silo"}})
script.on_event(defines.events.script_raised_built, rocketsilo_built, {{filter = "type", type = "rocket-silo"}})
script.on_event(defines.events.script_raised_revive, rocketsilo_built, {{filter = "type", type = "rocket-silo"}})
script.on_event(defines.events.on_player_mined_entity, rocketsilo_mined, {{filter = "type", type = "rocket-silo"}})
script.on_event(defines.events.on_robot_mined_entity, rocketsilo_mined, {{filter = "type", type = "rocket-silo"}})
script.on_event(defines.events.on_entity_died, rocketsilo_mined, {{filter = "type", type = "rocket-silo"}})
script.on_event(defines.events.script_raised_destroy, rocketsilo_mined_script, {{filter = "type", type = "rocket-silo"}})
script.on_event(defines.events.on_rocket_launched, rocket_got_launched)
--script.on_event(defines.events.on_rocket_launch_ordered, rocket_launch_ordered)
--script.on_event(defines.events.on_cargo_pod_finished_ascending, cargo_pod_launched) 
script.on_event(defines.events.on_gui_opened, rocket_gui) 
script.on_event(defines.events.on_gui_closed, rocket_gui_close) 
script.on_event(defines.events.on_gui_elem_changed, rocket_gui_elem)
script.on_event(defines.events.on_gui_selection_state_changed, rocket_gui_elem) 
script.on_event(defines.events.on_entity_settings_pasted, rocket_settings_pasted)   

script.on_event(defines.events.on_tick, rocketsilo_tick)

script.on_init(init_all_rocketsilos)
script.on_configuration_changed(handle_configuration_changed)

if (script.active_mods['space-age']) then
	-- Will this ever happen?!
	script.on_event(defines.events.on_space_platform_built_entity, rocketsilo_built, {{filter = "type", type = "rocket-silo"}})
	script.on_event(defines.events.on_space_platform_mined_entity, rocketsilo_mined, {{filter = "type", type = "rocket-silo"}})
end

script.on_event(defines.events.on_entity_cloned,
	function(event)
		event.entity = event.destination
		rocketsilo_built(event)
	end,
	
	{{filter = "type", type = "rocket-silo"}}
)


